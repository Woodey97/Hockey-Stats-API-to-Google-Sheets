from __future__ import print_function

import os.path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import requests
import json
import csv

url = "https://proclubs.ea.com/api/nhl/members/stats"
headers = {
    "Referer": "http://www.ea.com",
    "Accept-Language": "en-US,en;q=0.5",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0",
    "Connection": "keep-alive"
}
params = {
    "platform": "common-gen5",
    "clubId": "8789"
}
response = requests.get(url, headers=headers, params=params)



# print(response.text)

# The JSON data as a string
json_str = response.text

# Parse the JSON string into a dictionary
data = json.loads(json_str)['members']
# print (data[0])

# Extract the keys from the dictionary
keys = data[0].keys()

# Open a new CSV file for writing
with open('C:\\Users\\Mike\\Desktop\\YouTube\\UpdateStatscougs\\example.csv', 'w', newline='') as csv_file:
    writer = csv.DictWriter(csv_file, fieldnames=keys)

    # Write the header row with the column names
    writer.writeheader()

    # Write the data row to the CSV file
    for row in data:
        writer.writerow(row)

sheetsdata = []

sheetheader = []
for key in keys:
    sheetheader.append(key)
sheetsdata.append(sheetheader)

for datarow in data:
    sheetrow = [] 
    for key in keys:
        sheetrow.append(datarow[key])
    sheetsdata.append(sheetrow)
# print (sheetsdata)


SCOPES = ['https://www.googleapis.com/auth/spreadsheets']


def update_values(spreadsheet_id, range_name, value_input_option,
                  _values):
    """
    Creates the batch_update the user has access to.
    Load pre-authorized user credentials from the environment.
    TODO(developer) - See https://developers.google.com/identity
    for guides on implementing OAuth2 for the application.
        """
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('C:\\Users\\Mike\\Desktop\\YouTube\\UpdateStatscougs\\token.json'):
        creds = Credentials.from_authorized_user_file('C:\\Users\\Mike\\Desktop\\YouTube\\UpdateStatscougs\\token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'C:\\Users\\Mike\\Desktop\\YouTube\\UpdateStatscougs\\credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('C:\\Users\\Mike\\Desktop\\YouTube\\UpdateStatscougs\\token.json', 'w') as token:
            token.write(creds.to_json())
    # pylint: disable=maybe-no-member
    try:

        service = build('sheets', 'v4', credentials=creds)
        # values = [
        #     [
        #         # Cell values ...
        #     ],
        #     # Additional rows ...
        # ]
        body = {
            'values': _values
        }
        result = service.spreadsheets().values().update(
            spreadsheetId=spreadsheet_id, range=range_name,
            valueInputOption=value_input_option, body=body).execute()
        print(f"{result.get('updatedCells')} cells updated.")
        return result
    except HttpError as error:
        print(f"An error occurred: {error}")
        return error


# Pass: spreadsheet_id,  range_name, value_input_option and  _values
update_values("1UryXfwQwSttzivGq9lN9V-lMcZcQs1BK1yrDk4BrCv4",
                "Sheet7!A:GB", "RAW", sheetsdata)